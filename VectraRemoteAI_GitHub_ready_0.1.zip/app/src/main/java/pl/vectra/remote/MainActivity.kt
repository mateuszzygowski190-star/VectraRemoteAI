package pl.vectra.remote

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*

/** UI prototype. Remote transport is deliberately NOT simulated. */
class MainActivity : Activity() {
    private lateinit var status: TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 42, 32, 24)
            setBackgroundColor(Color.rgb(245, 247, 250))
        }
        fun text(value: String, size: Float): TextView = TextView(this).apply {
            text = value; textSize = size; setTextColor(Color.rgb(22, 34, 51))
            setPadding(0, 8, 0, 8)
        }
        root.addView(text("Vectra Remote AI", 25f))
        root.addView(text("Prototyp aplikacji Android — wersja 0.1", 14f))
        status = text("Niepołączono. Moduł parowania Android TV Remote v2 wymaga implementacji.", 14f)
        root.addView(status)
        val grid = GridLayout(this).apply { columnCount = 3 }
        val keys = listOf("HOME", "↑", "BACK", "←", "OK", "→", "VOL −", "↓", "VOL +", "MUTE", "PLAY", "POWER")
        keys.forEach { key ->
            val button = Button(this).apply {
                text = key
                setOnClickListener { status.text = "Polecenie $key nie zostało wysłane: brak połączenia z dekoderem." }
            }
            grid.addView(button, GridLayout.LayoutParams().apply {
                width = 0; height = GridLayout.LayoutParams.WRAP_CONTENT
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
            })
        }
        root.addView(grid)
        root.addView(text("Następny etap: bezpieczne parowanie kodem TV, TLS i obsługa przycisków przez Android TV Remote v2.", 13f))
        val scroll = ScrollView(this); scroll.addView(root); setContentView(scroll)
    }
}
